/**
 * Verkefni 7 – Caesar dulmál
 */

const LETTERS = `AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖ`;
let strIn;
let str = "";
let bool;
let invalid;
/**
 * Byrja forrit.
 */
function start() {
  let inputPending = true;
  while(inputPending) {
    let inputAction = prompt(`Hvort viltu kóða eða afkóða streng? Skrifaðu „kóða“ eða „afkóða“`);
    if (inputAction != `kóða` && inputAction != `afkóða`) {
      if(inputAction === null)
        break;
      alert(`Veit ekki hvaða aðgerð „${inputAction}“ er. Reyndu aftur.`);
      continue;
    }
    else {
      let inputShift = prompt(`Hversu mikið á að hliðra streng? Gefðu upp heiltölu á bilinu [1, 31]`);
      if(inputShift === null)
        break;
      if (inputShift < 1 || inputShift > 31 || isNaN(inputShift)) {
        alert(`${inputShift} er ekki heiltala á bilinu [1, 31]. Reyndu aftur.`);
        continue;
      }
      else {
        strIn = prompt(`Gefðu upp strenginn sem á að ${inputAction} með hliðrun ${inputShift}:`);
        str = strIn.toLocaleUpperCase();
        bool = evaluate(str);
        invalid = invalidArray(str);

        if(str == "" || strIn === null) {
          alert(`Þú gafst ekki upp streng. Reyndu aftur.`);
          continue;
        }
        if(!bool){
          alert(`Þú gafst upp stafi sem ekki er hægt að ${inputAction}: ${invalid.join(', ')}. Reyndu aftur.`);
          continue;
        }
        else {
          inputPending = false;
          let output = "";
          if(inputAction==`kóða`) {
            output = encode(str, inputShift);
          }
          else {
            output = decode(str, inputShift);
          }
          alert(`Niðurstaða: ` + output);
          inputPending = confirm(`Vinna með annan streng?`);
        }
      }
    }
  }
}

start();

/**
 * Segir hvort strengur innihaldi einungis löglega stafi eðaq ekki
 *
 * @param {string} str
 * @returns {boolean}
 */
function evaluate(str) {
  let ret = true;
  for(let i = 0;i<str.length;i++) {
    if(LETTERS.indexOf(str.charAt(i))==-1) {
      ret = false;
    }
  }
  return ret;
}
/**
 * Skilar stöfunum sem ekki eru löglegir í fylki
 * @param {string} str
 * @returns {Array}
 */
function invalidArray(str) {
  let retArr = [];
  for(let i = 0;i<str.length;i++) {
    if(LETTERS.indexOf(str.charAt(i))==-1) {
      retArr.push(str.charAt(i));
    }
  }
  return retArr;
}

/**
 * Kóðar streng með því að hliðra honum um n stök.
 *
 * @param {string} str Strengur sem skal kóða, aðeins stafir í stafrófi
 * @param {number} n Hliðrun, heiltala á bilinu [0, lengd stafrófs]
 * @returns {string} Upprunalegi strengurinn hliðraður um n til hægri
 */
function encode(str, n) {
  let enc = "";
  let shift = n % 32;
  let encIndex;
  for(let i = 0;i<str.length;i++) {
    encIndex = LETTERS.indexOf(str.charAt(i))+shift;
    while (encIndex>=32) {
      encIndex-=32;
    } //nú er 0  <=  encIndex  <=  31
    enc = enc.concat(LETTERS.charAt(encIndex));
  }
  return enc;
}

/**
 * Afkóðar streng með því að hliðra honum um n stök.
 *
 * @param {string} str Strengur sem skal afkóða, aðeins stafir í stafrófi
 * @param {number} n Hliðrun, heiltala á bilinu [0, lengd stafrófs]
 * @returns {string} Upprunalegi strengurinn hliðraður um n til vinstri
 */
function decode(str, n) {
  let dec = "";
  let shift = n % 32;
  let decIndex;
  for(let i = 0;i<str.length;i++) {
    decIndex = LETTERS.indexOf(str.charAt(i))-shift;
    while (decIndex<0) {
      decIndex += 32;
    } //núna er 0  <=  decIndec  <=  31
    dec = dec.concat(LETTERS.charAt(decIndex));
  }
  return dec;
}

console.assert(encode('A', 3) === 'D', 'kóðun á A með n=3 er D');
console.assert(decode('D', 3) === 'A', 'afkóðun á D með n=3 er A');
console.assert(encode('AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖ', 32) === 'AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖ', 'kóðun með n=32 er byrjunarstrengur');
console.assert(encode('AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖ', 3) === 'DÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖAÁB', 'kóðun á stafrófi með n=3');
console.assert(decode('DÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖAÁB', 3) === 'AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖ', 'afkóðun á stafrófi með n=3');
console.assert(decode(encode('HALLÓHEIMUR', 13), 13) === 'HALLÓHEIMUR', 'kóðun og afkóðun eru andhverf');
